# Rapid-Tree-Note
    Tree Markup Notetaking System

    This Project inspired by the behavior seen on https://tree.nathanfriend.io/
    All code is original.
    All code written by Brendan Rood in collaboration with the LARSLab and MMADLab at the University of Minnesota  Duluth